package board.DAO;

import com.alohaclass.jdbc.dao.BaseDAOImpl;

import board.DTO.Users;

public class UserDAO extends BaseDAOImpl<Users> {
	
}