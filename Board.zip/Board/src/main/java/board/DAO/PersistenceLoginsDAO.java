package board.DAO;

import com.alohaclass.jdbc.dao.BaseDAOImpl;

import board.DTO.PersistenceLogins;

public class PersistenceLoginsDAO extends BaseDAOImpl<PersistenceLogins> {

}