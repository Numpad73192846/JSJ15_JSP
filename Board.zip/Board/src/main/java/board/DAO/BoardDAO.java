package board.DAO;

import com.alohaclass.jdbc.dao.BaseDAOImpl;

import board.DTO.Board;

public class BoardDAO extends BaseDAOImpl<Board> {

}